﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Datalist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Page.IsPostBack == false)
        {

            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con1.Open();
            string str1 = "Select * from Product";
            SqlCommand cmd1 = new SqlCommand(str1, con1);
            

            SqlDataReader dr1;
            dr1 = cmd1.ExecuteReader();
            DataList1.DataSource = dr1;
            DataList1.DataBind();


            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string str = "Select * from Category";
            SqlCommand cmd = new SqlCommand(str, con);
           

            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            drpCategory.DataSource = dr;
            drpCategory.DataTextField = "CategoryName";
            drpCategory.DataValueField = "CategoryId";
            drpCategory.DataBind();


        }
        
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Select * from Product Where CategoryId='" + drpCategory.SelectedItem.Value + "'";
        SqlCommand cmd = new SqlCommand(str, con);
        
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataList1.DataSource = dr;
        DataList1.DataBind();
        Session["SelectedCategoryId"] =drpCategory.SelectedItem.Value;
    }

    public void Hi(object sender, DataListCommandEventArgs e)
    {
        int i;
        i = Convert.ToInt16(e.CommandArgument);

        Session["ProductId"] = i;

         if (e.CommandName == "DetailButton")
        {
            Response.Redirect("ViewDetail.aspx");
        }


        if (e.CommandName == "BuyButton")
        {

            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con1.Open();
            string str1 = "Select Name,Price from Product where ProductId='"+i+"'";
            SqlCommand cmd1 = new SqlCommand(str1, con1);
            

            SqlDataReader dr1;
            dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                Session["ProductName"] = dr1["Name"];
                Session["Price"] = dr1["Price"];
            }



            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string str = "Insert Into Payment Values('"+i+"','"+Session["UserDetailid"]+"','"+Session["Price"]+"','"+System.DateTime.Now.ToShortDateString()+"','"+System.DateTime.Now.ToShortTimeString()+"','Pending')";
            SqlCommand cmd = new SqlCommand(str, con);
            

            cmd.ExecuteNonQuery();


            SqlConnection con2 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con2.Open();
            string str2 = "Select Max(PaymentId) from Payment";
            SqlCommand cmd2 = new SqlCommand(str2, con2);
           

            Session["PaymentId"] = cmd2.ExecuteScalar();
            Response.Redirect("LOGIN.aspx");

            Response.Redirect("Booking.aspx");


        }
   }
    
    protected void drpCategory_SelectedIndexChanged1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Select * from Product Where CategoryId='" + drpCategory.SelectedItem.Value + "'";
        SqlCommand cmd = new SqlCommand(str, con);
       
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataList1.DataSource = dr;
        DataList1.DataBind();
    
    }
 
    
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "select * from Product where Name Like'%" + txtsearch.Text + "%'";
        SqlCommand cmd = new SqlCommand(str, con);
        

        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        DataList1.DataSource = dr;

        DataList1.DataBind();
    }
}

  
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Success : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            string str1 = "Select TotalRoom from Category";

            SqlCommand cmd1 = new SqlCommand(str1, con1);
            con1.Open();

            Session["TotalRoom"] = cmd1.ExecuteScalar();


            int i = Convert.ToInt16(Session["TotalRoom"]);

            int ac = i - 1;
            string a = ac.ToString();
            int j = Convert.ToInt16(Session["SelectedCategoryId"]);
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

            string str;
            str = "Update Category set TotalRoom='" + a + "' where CategoryId='" + j + "'";


            SqlCommand cmd = new SqlCommand(str, con);

            con.Open();

            cmd.ExecuteNonQuery();
        }
    }
    protected void lnkHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("HomePage.aspx");
    }
}
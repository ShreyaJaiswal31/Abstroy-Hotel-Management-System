﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            LinkButton3.Visible = true;
            LinkButton4.Visible = false;
            Label1.Text = Session["UserName"].ToString();

        }
        else
        {
            LinkButton3.Visible = false;
        }
    }
   
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("REGISTRATION.aspx");
    }
    
    
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("HomePage.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("LOGIN.aspx");
    }
}

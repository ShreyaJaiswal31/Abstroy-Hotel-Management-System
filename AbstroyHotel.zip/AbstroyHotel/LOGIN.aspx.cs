﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//Namespace
using System.Data.SqlClient;


public partial class LOGIN : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str;
        str = "Select Count(*) from table1 where Username='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'";

        SqlCommand cmd = new SqlCommand(str, con);
       

        int i;

        i = Convert.ToInt16(cmd.ExecuteScalar());

        if (i == 1)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con1.Open();
            string str1;
            str1 = "Select UserDetailId from table1 where UserName='" + txtusername.Text + "' ";

            SqlCommand cmd1 = new SqlCommand(str1, con1);
           
            Session["UserDetailId"] = cmd1.ExecuteScalar();

            Session["UserName"] = txtusername.Text;



            if (Session["ProductName"] != null)
            {
                Response.Redirect("Booking.aspx");
            }

           else
            {
                Response.Redirect("Datalist.aspx");
            }

        }

        else
        {
            lblmessage.Text = "Invalid UserName And Password";
        }


        int j;
        j = Convert.ToInt16(cmd.ExecuteScalar());

        if (j != 1)
        {

            SqlConnection con2 = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\REGESTRATION.mdf;Integrated Security=True;User Instance=True");
            string str2;
            str2 = "Select  UserDetailId from table1 where UserName='ADMIN' and Password='ABSTROY'";

            SqlCommand cmd2 = new SqlCommand(str2, con2);
            con2.Open();

            Session["UserDetailId"] = cmd2.ExecuteScalar();

            Session["UserName"] = "ADMIN";

            Response.Redirect("Updatepage.aspx");
        }
        else
        {
            Response.Redirect("HomePage.aspx");
        }
    }
    
   

    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("ForgotPassword.aspx");
    }


    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("changepassword.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("REGISTRATION.aspx");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net.Mail;

public partial class ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con1.Open();

        string str1 = "Select count(*) from table1 where Email='" + txtemail.Text + "' ";

        SqlCommand cmd1 = new SqlCommand(str1, con1);
       
        int i;
        i = Convert.ToInt16(cmd1.ExecuteScalar());
        if (i == 1)
        {

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();

            string str = "select Password from table1 where Email='"+txtemail.Text+"' ";

            SqlCommand cmd = new SqlCommand(str, con);
            
            string psw;

            psw = (cmd.ExecuteNonQuery()).ToString();


            /////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////


            //Automatic Mail
            try
            {
                MailMessage Msg = new MailMessage();
                // Sender e-mail address.
                Msg.From = new MailAddress("your mailid");
                // Recipient e-mail address.
                Msg.To.Add(txtemail.Text);
                Msg.Subject = "Update Of your Password";
                //Msg.Body = "Your Category is:" + Session["Category"].ToString();

                string body = "Your Password is:" + psw + "<br />";
                //body += "";

                Msg.Body = body;

                Msg.IsBodyHtml = true;
                //if (FileUpload1.HasFile)
                //{

                //    Msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, FileUpload1.FileName));

                //}
                // your remote SMTP server IP.
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("your mailid", "password");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                Msg = null;
                Page.RegisterStartupScript("UserMsg", "<script>alert('Mail sent thank you...');if(alert){ window.location='login.aspx';}</script>");
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} Exception caught.", ex);
            }


        }
        else
        {
            lblmsg.Text = "Inva....";
        }
    }

    }

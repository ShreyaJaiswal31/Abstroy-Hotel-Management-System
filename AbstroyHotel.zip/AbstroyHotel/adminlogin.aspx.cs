﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class adminlogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnalogin_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str;
        str = "select count(*) from AdminLogin  where Username='" + txtausername.Text + "' and Password='" + txtapassword.Text + "'";
        SqlCommand cmd = new SqlCommand(str, con);
       

        int i;
        i = Convert.ToInt16(cmd.ExecuteScalar());
        if (i== 1)
        {
            lblamessage.Text = "Login Successfully";
            Response.Redirect("InsertCategory.aspx");
        }
        else
        {
            lblamessage.Text = "Invalid UserName & Password";
        }
    }
}
    

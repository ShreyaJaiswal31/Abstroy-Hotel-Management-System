﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class changepassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnchangepassword_Click(object sender, EventArgs e)
    {
        
        SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con1.Open();
        string str1 = "Select password from table1 where Username='" + txtusername.Text + "'";



        SqlCommand cmd1 = new SqlCommand(str1, con1);
        

        string pwd;
        pwd = Convert.ToString(cmd1.ExecuteScalar());
        if (pwd == txtoldpassword.Text)
        {

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();


            string str = "update table1 set password='" + txtnewpassword.Text + "' where username='" + txtusername.Text + "'";


            SqlCommand cmd = new SqlCommand(str, con);
            
            cmd.ExecuteNonQuery();
            {
                lblmsg.Text = "Changepassword Successfully";
            }

        }
        else
        {
            lblmsg.Text = "Invalid";
        }

    }
    protected void txtnewpassword_TextChanged(object sender, EventArgs e)
    {

    }
}
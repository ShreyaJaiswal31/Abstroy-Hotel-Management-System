﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net.Mail;

public partial class Feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Insert Into feedback(name,address,contactno,email,yourfeedback)values('" + txtname.Text + "','" + txtaddress.Text + "','" + txtcontact.Text + "','" + txtemail.Text + "','" + txtfeedback.Text + "')";
        SqlCommand cmd = new SqlCommand(str, con);
        
        cmd.ExecuteNonQuery();

       



        /////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////


            //Automatic Mail
            try
            {
                MailMessage Msg = new MailMessage();
                // Sender e-mail address.
                Msg.From = new MailAddress(txtemail.Text);
                // Recipient e-mail address.
                Msg.To.Add("your mailid");
                Msg.Subject = "Update Of your feedback";
                //Msg.Body = "Your Category is:" + Session["Category"].ToString();

                string body = "Your feedback is:" +txtfeedback.Text+ "<br />";
                //body += "";

                Msg.Body = body;

                Msg.IsBodyHtml = true;
                //if (FileUpload1.HasFile)
                //{

                //    Msg.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, FileUpload1.FileName));

                //}
                // your remote SMTP server IP.
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("your mailid", "password");
                smtp.EnableSsl = true;
                smtp.Send(Msg);
                Msg = null;
                Page.RegisterStartupScript("UserMsg", "<script>alert('Mail sent thank you...');if(alert){ window.location='login.aspx';}</script>");
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} Exception caught.", ex);
            }


        }
       
    


    }

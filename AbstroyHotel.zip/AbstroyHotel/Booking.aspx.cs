﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Booking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        lblusername.Text=Session["UserName"].ToString();
        lblSelectedProduct.Text = Session["ProductName"].ToString();
        lblPrice.Text = Session["Price"].ToString();

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Select * from table1 where Username='"+Session["UserName"]+"'";
        SqlCommand cmd = new SqlCommand(str,con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            lblFirstName.Text=dr["Firstname"].ToString();
            lblLastName.Text = dr["Lastname"].ToString();  
            lblContectNo.Text=dr["Phoneno"].ToString();


        }


    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("Login.aspx");
        }

        lblusername.Text = Session["UserName"].ToString();


        int i=Convert.ToInt16(Session["TotalRoom"]);
        if(i==0)
        {
            lblMsg1.Text = Session["ProductName"].ToString()+ "is not available..";
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Insert Into Booking Values('" + Session["UserDetailId"] + "','" + Session["Productid"] + "','" + txtStartDate.Text + "','" + txtEndDate.Text + "','" + Session["Price"] + "')";
        SqlCommand cmd = new SqlCommand(str, con);
       
        cmd.ExecuteNonQuery();

        Response.Redirect("Buynow.aspx");
        Response.Redirect("LOGIN.aspx");

    }
}
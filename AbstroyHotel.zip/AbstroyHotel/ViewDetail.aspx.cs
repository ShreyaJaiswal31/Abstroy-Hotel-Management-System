﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class ViewDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Select * from Product Where ProductId='" + Session["ProductId"] + "'";
        SqlCommand cmd = new SqlCommand(str, con);
        
       

        SqlDataReader dr;
        dr = cmd.ExecuteReader();


        while (dr.Read())
        {
            lblName.Text = dr["Name"].ToString();
            Image2.ImageUrl = @"Rooms/" + dr["ImageName"].ToString();
            lblLongdesc.Text = dr["Longdesc"].ToString();
            lblprice.Text = dr["Price"].ToString();
            
        }
    }

   
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Datalist.aspx");
    }
}
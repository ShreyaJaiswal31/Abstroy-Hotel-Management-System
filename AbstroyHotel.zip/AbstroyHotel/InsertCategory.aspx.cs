﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class InsertCategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "Insert into Category(CategoryName,TotalRoom) values('"+txtCategory.Text+"','10')";

        SqlCommand cmd = new SqlCommand(str,con);
       

        cmd.ExecuteNonQuery();
        lblMessage.Text = "Successfully";
        txtCategory.Text = string.Empty;
        Response.Redirect("InsertProduct.aspx");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class REGESTRATION : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnregestration_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con1.Open();
        string str1 = "select count(*) from table1 where Username='" + txtusername.Text + "' and Password='" + txtpassword.Text + "'";
        SqlCommand cmd1 = new SqlCommand(str1, con1);
       
        int i;
        i = Convert.ToInt16(cmd1.ExecuteScalar());
        if (i == 1)
        {
            lblmessage.Text = "Username is already exist";
            return;
        }


        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string str = "insert into table1(FirstName,LastName,UserName,Password,Email,Phoneno,City) values ('" + txtfirstname.Text + "','" + txtlastname.Text + "','" + txtusername.Text + "','" + txtpassword.Text + "','" + txtemail.Text + "','" + txtphoneno.Text + "','" + txtcity.Text + "')";
        SqlCommand cmd = new SqlCommand(str, con);
        
        cmd.ExecuteNonQuery();
        lblmessage.Text = "Regestration Successfully";

        Response.Redirect("LOGIN.aspx");
    }
}
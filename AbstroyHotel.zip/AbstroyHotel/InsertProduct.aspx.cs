﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class InsertProduct : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string str = "Select * from Category";
            SqlCommand cmd = new SqlCommand(str, con);
           

            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            drpCategory.DataSource = dr;
            drpCategory.DataTextField = "CategoryName";
            drpCategory.DataValueField = "CategoryId";
            drpCategory.DataBind();
            drpCategory.Items.Insert(0, new ListItem("SELECT", "0"));
           
        }


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath(".")+@"\Rooms\"+FileUpload1.FileName);
        }


        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\REGESTRATION.mdf;Integrated Security=True;Connect Timeout=30");
        con.Open();
        string  str ="Insert Into Product values('"+drpCategory.SelectedItem.Value+"','"+txtName.Text+"','"+txtPrice.Text+"','"+txtShortdesc.Text+"','"+TextBox1.Text+"','"+FileUpload1.FileName+"','NO')";
        SqlCommand cmd = new SqlCommand(str,con);
        
        cmd.ExecuteNonQuery();
        lblmessage.Text="Successfully";

    }

  
}